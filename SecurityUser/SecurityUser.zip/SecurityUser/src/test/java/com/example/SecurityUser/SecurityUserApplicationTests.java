package com.example.SecurityUser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
